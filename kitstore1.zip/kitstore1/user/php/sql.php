<?php 
    if(isset($_POST['submit'])){
        include 'config.php';
    }
$name= $_POST['name'];
?>