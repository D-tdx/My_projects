<?php

require("conn.php");

session_start();
if(!empty($_SESSION['Admin_Name'])){
  echo "<script>
          window.location = 'index.html';
  </script>";
  exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<!-- Basic -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Kitstore-Login</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/kiticon.png" type="image/x-icon">
    

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <style>
	.btn-color{
  background-color: #4ABAF2;
  color: #fff; 
}
.profile-image-pic{
  height: 200px;
  width: 200px;
  object-fit: cover;
}
.cardbody-color{
  background-color: #ebf2fa;
}

a{
  text-decoration: none;
}
</style>


    <body>
      <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.html"><img src="images/kitlogo.png" class="logo" alt=""></a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="navbar-menu">
					<ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
						<li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
						<li class="nav-item"><a class="nav-link" href="shop.html">Shop</a></li>
						<li class="nav-item active"><a class="nav-link" href="contact-us.html">Contact Us</a></li>
                        <li class="nav-item active"><a class="nav-link" href="cart.html">Go to Cart</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
        </nav>
    </header>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">

          <form action="" method="POST" class="card-body cardbody-color p-lg-5">
          		  <h2 class="text-center text-dark">Admin </h2>
            <div class="text-center">
              <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                width="200px" alt="profile">
            </div>

            <div class="mb-3">
              <input type="text" name="Admin_Name" class="form-control" id="Admin_Name" aria-describedby="emailHelp"
                placeholder="Admin Name">
            </div>
            <div class="mb-3">
              <input type="password" name="Admin_Password" class="form-control" id="Admin_Password" placeholder="Admin_Password">
            </div>
            <div class="text-center"><input type="submit" name="submit" value="Sign In" class="btn btn-color px-5 mb-5 w-100"></div>
            
          </form>
        </div>

      </div>
    </div>
  </div>
      <!-- Start Footer  -->
      <footer>
        <div class="footer-main">
            <div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Business Time</h3>
							<ul class="list-time">
								<li>Monday - Friday: 08.00am to 05.00pm</li> <li>Saturday: 10.00am to 08.00pm</li> <li>Sunday: <span>Closed</span></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Newsletter</h3>
							<form class="newsletter-box">
								<div class="form-group">
									<input class="" type="email" name="Email" placeholder="Email Address*" />
									<i class="fa fa-envelope"></i>
								</div>
								<button class="btn hvr-hover" type="submit">Submit</button>
							</form>
						</div>
					</div>
					<div class="col-lg-4 col-md-12 col-sm-12">
						<div class="footer-top-box">
							<h3>Social Media</h3>
							<p>Fell free to contact us and keep updates about your order.</p>
							<ul>
                                <li><a href="https://twitter.com/Deb_techGeek"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="https://www.linkedin.com/in/debanjan-biswas-6672a628b/"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                            </ul>
						</div>
					</div>
				</div>
				<hr>
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About Kitstore</h4>
                            <p>We are a Kolkata based football Jersy and kits store that Will amaze you with variety of new collections. We provide home delivery in all over India.</p> 
							<p>New Seasons jerseys with a huge range of stock and Retro jerseys with limited stocks that are waiting to get wear by our upcoming football stars. </p> 							
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                            <h4>Information</h4>
                            <ul>
                                <li><a href="#">Customer Service</a></li>
                                <li><a href="#">Our Sitemap</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Delivery Information</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: 213,P-2/B,Sarat Bose Street <br>Near Miadan Metro Station, Maidan<br> Kol-004023 </p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+91-6290747648">+91-6290747648</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:dbiswasdrt1@gmail.com">dbiswasdrt1@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer  -->
       <!-- Start copyright  -->
       <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2023 <a href="#">D&SComp</a> Design By :
            <a href="https://html.design/">Debanjan Biswas</a></p>
    </div>
    <!-- End copyright  -->
  </body>
</html>


<?php
if(isset($_POST['submit'])){

  include 'sql/config.php';

  $sql = mysqli_query($conn, "SELECT * FROM admin_panel WHERE Admin_Name = '$_POST[Admin_Name]' AND Admin_Password = '$_POST[Admin_Password]'");

  if(mysqli_num_rows($sql)>0){

    $_SESSION['Admin_Name'] = $_POST['Admin_Name'];

    header('Location: index.html'); 
  }else{
    echo "<script>
            alert('Wrong Information Provided');
    </script>";
  }
}
?>
