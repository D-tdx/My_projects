<?php 

mysqli_connect("localhost","root"," ","kitstoreserver");
 
if(mysqli_connect_error())
{
    echo "Can not connect";
}
else{
    echo "Connected";
}

?>