<?php

if(isset($_POST['update'])){

	include 'config.php';


	$name = $_POST['name'];
    $item = $_POST['item']
	$price = $_POST['price'];
	$image = $_FILES['pic'];


	move_uploaded_file($_FILES['pic']['tmp_name'], '../image/' .$_FILES['pic']);

	$sql = "UPDATE `shopitem` SET `name`='$name',`item`='$item',`price`='$price',`image`='$image' WHERE name='$name'";

	if(mysqli_query($conn , $sql)){
		echo "<script>
				
				window.location = 'http://localhost/kitstore1/admin/shop.php';
		</script>";
	}else{
		echo "error" .mysqli_error($conn);
	}
}



?>