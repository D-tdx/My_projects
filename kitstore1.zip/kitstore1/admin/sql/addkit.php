<?php

if(isset($_POST['submit'])){

	include 'config.php';


    $name= $_POST['name'];
	$item = $_POST['item'];
	$price = $_POST['price'];
	$image = $_FILES['image'];

	move_uploaded_file($_FILES['image']['tmp_name'], '../images/' .$_FILES['image']['name']);

	$sql ="INSERT INTO `shopitem`(`name`, `item`, `price`, `image`) VALUES ('$name','$item','$price','$image')" 
    	
    if(mysqli_query($conn , $sql)){
		
        echo "<script>
				alert('Item Added Successfully');
				window.location = 'http://localhost/kitstore1/admin/shop.php';
		</script>";
	}else{
		echo "error" .mysqli_error($conn);
	}
}

?>