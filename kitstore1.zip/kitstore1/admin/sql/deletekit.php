<?php

include 'config.php';

$name = $_GET['name'];

$sql = "DELETE FROM shopitem WHERE name = 'name'";

if(mysqli_query($conn , $sql)){
		echo "<script>
				alert('Item Delete Successfully');
				window.location = 'http://localhost/kitstore1/admin/shop.php';
		</script>";
	}else{
		echo "error" .mysqli_error($conn);
	}

?>